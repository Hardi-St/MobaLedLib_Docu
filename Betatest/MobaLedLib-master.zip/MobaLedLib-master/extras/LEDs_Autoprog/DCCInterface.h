#ifndef DCCINTERFACE_H
#define DCCINTERFACE_H

#include <EEPROM.h>
#include <NmraDcc.h>

class DCCInterface
{

public:
	static void	setup(int DCCSignalPin, int statusLedPin);
	static void	process();
private:	
	static void processErrorLed();
};
#endif