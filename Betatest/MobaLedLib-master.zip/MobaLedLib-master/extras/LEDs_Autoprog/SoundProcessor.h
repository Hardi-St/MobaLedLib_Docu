#ifndef SoundProcessor_H
#define SoundProcessor_H

/*
 MobaLedLib: LED library for model railways
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 Copyright (C) 2018 - 2021  Hardi Stengelin: MobaLedLib@gmx.de

 this file: Copyright (C) 2021 J�rgen Winkler: MobaLedLib@a1.net

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 -------------------------------------------------------------------------------------------------------------


 Revision History :
~~~~~~~~~~~~~~~~~
07.10.21:  Versions 1.0 (J�rgen)

*/

//#include "defines.h"

#if !defined(ESP32)
  #include "SoftwareSerialTX.h"
  #define SOFTWARE_SERIAL_TYPE SoftwareSerialTX
  #define SOFTWARE_SERIAL(pin) new SOFTWARE_SERIAL_TYPE(txPin)

#else
  #include <SoftwareSerial.h>
  #define SOFTWARE_SERIAL_TYPE SoftwareSerial
  #define SOFTWARE_SERIAL(pin) new SOFTWARE_SERIAL_TYPE(-1, txPin)
#endif

#ifndef DELAY_AFTER_SOUND_PACKET
#define DELAY_AFTER_SOUND_PACKET 15
#endif

// The JQ6500 sound module is delivered with various sound chips
// the original JQ6500 Module has a JQ6500 sound chip on board
// also we can find JQ6500 moduls with cips AA20HGN403 or AA20HFJ648 or ???
// the so fast tested modules with AA* chip behave different,  serial messages must be sent without any breaks. If the delay between two bytes exceeds 600us the packet is ignored by the chip
//
// by default MLL sends one byte in each main loop cycle to ensure that LED stream is not interrupted for too long. Sending all byte at once delays the main loop by ~5ms, which should be avoided
// but with JQ6500 modules having the AA* chips onboard we need to send a full packet at once, because the main loop cylce time is >2ms.
// to enable this feature you need to define _SOUNDPROCCESSOR_SEND_FULL_PACKET preprocessor variable

//#define _SOUNDPROCCESSOR_SEND_FULL_PACKET

// sound chips tests so fast
// JQ6500: works fine
// AA20HGN403: no delay accepted, need to use _SOUNDPROCCESSOR_SEND_FULL_PACKET
// AA20HFJ648: no delay accepted, need to use _SOUNDPROCCESSOR_SEND_FULL_PACKET


#define JQ6500_CMD_BEGIN    0x7E
#define JQ6500_CMD_END      0xEF
#define JQ6500_CMD_PLAY_IDX 0x03
#define JQ6500_CMD_VOL_UP   0x04
#define JQ6500_CMD_VOL_DN   0x05
#define JQ6500_CMD_VOL_SET  0x06
#define JQ6500_CMD_PLAY     0x0D
#define JQ6500_CMD_PAUSE    0x0E
#define JQ6500_CMD_LOOP_SET 0x11

/****************************************/
/* DEBUG_SOUND_CHANNEL is bit coded     */
/*                                      */
/* 0x01 show generic command executing  */
/* 0x02 show sound command executing    */
/* 0x04 show sound command details      */
/* 0x08 show bytes sent to serial line  */
/* 0x80 show all command handling calls */
/****************************************/

extern  MobaLedLib_C MobaLedLib;

class SoundSerialDispatcher
{
  private:
  uint8_t* buffer;
  uint8_t  capacity;
  uint8_t  count = 0;
  SOFTWARE_SERIAL_TYPE** serialLines;
  unsigned long waitUntil = 0;

  public:
  SoundSerialDispatcher(uint8_t* buffer, uint8_t capacity, SOFTWARE_SERIAL_TYPE* serialLines[])
  {
    this->buffer = buffer;
    this->capacity = capacity;
    this->serialLines = serialLines;
  }

  // moduleId 0..15
  // length 0..15
  bool Add(uint8_t moduleId, uint8_t* message, uint8_t length)
  {
    //TODO check length
    while (count+length>=capacity)
    {
       if (!Process()) delay(1);
    }
    buffer[count++] = (moduleId<<4) + length;
    memcpy(buffer+count, message, length);
    count+=length;
    return true;
  }

  //optional improvement: WAIT Time per channel
  bool Process()
  {
#ifndef _SOUNDPROCCESSOR_SEND_FULL_PACKET
      if (!count) return true;
#endif
      if (waitUntil!=0 && millis()<waitUntil)
      {
#if (DEBUG_SOUND_CHANNEL&0x08)==0x08
        { char s[80]; sprintf(s, "Buffer count = %d, wait=%d.", count,waitUntil-millis()); Serial.println(s); Serial.flush();} // Debug
#endif
        return false;
      }
#if (DEBUG_SOUND_CHANNEL&0x08)==0x08
      if (count) { char s[80]; sprintf(s, "Buffer count = %d.", count); Serial.println(s); Serial.flush();} // Debug
#endif


#ifdef _SOUNDPROCCESSOR_SEND_FULL_PACKET
      while (count)
#endif
      {
        uint8_t tmp = buffer[0];

        // debug output doesn't work with modules that don't support delay between serial chars
#if ((DEBUG_SOUND_CHANNEL&0x08)==0x08) && (!defined(_SOUNDPROCCESSOR_SEND_FULL_PACKET) || defined(ESP32) || defined (PICO))
        { char s[80]; sprintf(s, "Sending %x of %d. Module %d, PacketLen %d.", buffer[1], count,tmp>>4,tmp&0x0f); Serial.println(s); Serial.flush();} // Debug
#endif
        serialLines[tmp>>4]->write(buffer[1]);
        buffer[0]--;
        if ((tmp&0x07)==1)    // last byte of this package
        {
          count -=2;
          memmove(buffer, buffer+2, count);
          waitUntil = millis()+DELAY_AFTER_SOUND_PACKET;
#ifdef _SOUNDPROCCESSOR_SEND_FULL_PACKET
          break;
#endif
        }
        else
        {
          count--;
          memmove(buffer+1, buffer+2, count-1);
          waitUntil = 0;
        }
      }
      return true;
  }
};

class SoundPlayer
{
  public:
  virtual void Handle(const uint8_t command, const uint8_t argument, const uint8_t* arguments) = 0;
};

class SoundProcessor
{
  public:
  uint8_t Handle(const uint8_t* arguments, bool process, SoundPlayer* soundPlayers[])
  {
    uint16_t cmdAndIndex = pgm_read_word_near(arguments+1);
#if (DEBUG_SOUND_CHANNEL&0x80)==0x80
    { char s[80]; sprintf(s, "Command %d on module %d.", cmdAndIndex & 0x0f, (cmdAndIndex >>4)&0x0f); Serial.println(s); Serial.flush();} // Debug
#endif
    if (process)
    {
      uint8_t tmp = MobaLedLib.Get_Input(pgm_read_byte_near(arguments));
      if (tmp==INP_TURNED_ON)
      {
#if (DEBUG_SOUND_CHANNEL&0x01)==0x01
        { char s[80]; sprintf(s, "Command %d/%d on module %d.", cmdAndIndex&0x0f, cmdAndIndex>>8, (cmdAndIndex>>4)&0x0f); Serial.println(s); Serial.flush();} // Debug
#endif
        soundPlayers[(cmdAndIndex>>4)&0x0f]->Handle(cmdAndIndex&0x0f, cmdAndIndex>>8, arguments+2);
      }
    }
    // commands 0..7 have no argument, other command have one argument
    return ((cmdAndIndex&0x0f)>=8)?3:2;
  }

  static SOFTWARE_SERIAL_TYPE* CreateSoftwareSerial(const byte txPin, uint16_t baudrate)
  {
      SOFTWARE_SERIAL_TYPE* result = SOFTWARE_SERIAL(txPin);
      result->begin(baudrate);
      return result;
  }
};

class JQ6500SoundPlayer : public SoundPlayer
{
  private:
  uint8_t moduleId;
  SoundSerialDispatcher* serialDispatcher;
  
  public:
  JQ6500SoundPlayer(uint8_t moduleId, SoundSerialDispatcher* serialDispatcher)
  {
    this->moduleId = moduleId;
    this->serialDispatcher = serialDispatcher;
  }
  
  //uint8_t buffer[] = {JQ6500_CMD_BEGIN,2,0,0,0,JQ6500_CMD_END};
  void Handle(const uint8_t command, const uint8_t argument, const uint8_t* arguments) override 
  {
#if (DEBUG_SOUND_CHANNEL&0x02)==0x02
    { char s[80]; sprintf(s, "Handle Command %d, %d.", command, arguments); Serial.println(s); Serial.flush();} // Debug
#endif      
    uint8_t buffer[] {JQ6500_CMD_BEGIN,4,JQ6500_CMD_PLAY_IDX,0,argument,JQ6500_CMD_END};
    uint8_t argumentCount = 1;
    switch(command)
    {
      case 8: // command 8: PlayTrack, argument TrackNumber
#if (DEBUG_SOUND_CHANNEL&0x04)==0x04
        { char s[80]; sprintf(s, "JQ6500SoundPlayer play trackIndex %d on module %d.", argument, moduleId); Serial.println(s); Serial.flush();} // Debug
#endif          
        buffer[2] = JQ6500_CMD_PLAY_IDX; 
        argumentCount++;
        buffer[3] = 0;
        buffer[4] = argument;
        break;
      case 9: // command 9: Set Volume to percentage level
      {
        uint16_t vol = (argument*30)/100;
#if (DEBUG_SOUND_CHANNEL&0x04)==0x04
        { char s[80]; sprintf(s, "JQ6500SoundPlayer set volume %d on module %d.", argument, moduleId); Serial.println(s); Serial.flush();} // Debug
#endif          
        buffer[2] = JQ6500_CMD_VOL_SET; 
        buffer[3] = vol;
        break;
      }
      case 10: // command 9: Set loop mode
      {
#if (DEBUG_SOUND_CHANNEL&0x04)==0x04
        { char s[80]; sprintf(s, "JQ6500SoundPlayer set loop mode %d on module %d.", argument, moduleId); Serial.println(s); Serial.flush();} // Debug
#endif          
        buffer[2] = JQ6500_CMD_LOOP_SET; 
        buffer[3] = argument;
        break;
      }
        
      case 0: // command 0: Increase volume
      case 1: // command 1: decrease volume
#if (DEBUG_SOUND_CHANNEL&0x04)==0x04
        { char s[80]; sprintf(s, "JQ6500SoundPlayer volume %s on module %d.", command ? "DOWN" : "UP", moduleId); Serial.println(s); Serial.flush();} // Debug
#endif          
        buffer[2] = JQ6500_CMD_VOL_UP + command; 
        argumentCount--;
        break;

      case 2: // command 2: pause
      case 3: // command 3: continue
#if (DEBUG_SOUND_CHANNEL&0x04)==0x04
        { char s[80]; sprintf(s, "JQ6500SoundPlayer %s on module %d.", command==2 ? "PAUSE" : "CONTINUE", moduleId); Serial.println(s); Serial.flush();} // Debug
#endif          
        buffer[2] = JQ6500_CMD_PLAY+3-command; 
        argumentCount--;
        break;

      default: return;
    }
    buffer[1] = argumentCount+2;
    buffer[3+argumentCount] = JQ6500_CMD_END;
    serialDispatcher->Add(moduleId, &buffer[0], 4+argumentCount);
    return;
  }
};

#endif