#ifndef _FUSES_H_
#define _FUSES_H_

#include "Global_Defines.h"

void Print_Fuses(Chip_Data_T &Chip_Data);
#endif // _FUSES_H_
