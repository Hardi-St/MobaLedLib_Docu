// Hier werden die Namen des Netzteils definiert - max. 13 Zeichen
// -----------------
#define supply1 "Netzteil"    // Gutes Beispiel hier waere "5V Netzteil" oder "12V Netzteil"
#define supply2 "MobaLedLib"  // Gutes Beispiel hier waere "IRM-60-5 HBf"; Also Bezeichnung des Netzteils und Ort
