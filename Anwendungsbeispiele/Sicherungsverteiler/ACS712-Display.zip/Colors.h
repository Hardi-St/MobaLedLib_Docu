// Hier werden die drei Farben fuer die oben festgelegten Bereiche in HEX-Werten definiert => WS2812 LEDs
// Da wir es gewohnt sind, in RGB-Werten zu denken, empfiehlt sich folgende Website zum Umwandeln von RGB zu HEX:
// https://www.rgbtohex.net/
// -----------------
#define color0 0x000210 // sehr schwaches blau bei 12V
#define color1 0x000700 // sehr schwaches gruen bei 5V
#define color2 0x070700 // sehr schwaches orange
#define color3 0x070000 // sehr schwaches rot
#define color4 0xFF0000 // helles Rot

// Hier werden die drei Farben fuer die oben festgelegten Bereiche in RGB-Werten definiert => Schriftfarbe Display
// -----------------
#define typo0 0, 0,120,255 // blau
#define typo1 0,   0,255,0 // gruen
#define typo2 0, 255,255,0 // gelb
#define typo3 0, 255,  0,0 // rot
#define typo4 0, 255,  0,0 // rot
