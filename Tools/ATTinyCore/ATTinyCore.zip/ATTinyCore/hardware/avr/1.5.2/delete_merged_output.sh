#!/bin/bash
if [ "$1" == "false" ]; then
  rm "$2"
fi
